<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dish extends CI_Controller
{
    public $dishCRUD;

    public function __construct()
    {
        parent::__construct();

        $this->load->model('DishCRUDModel');

        $this->dishCRUD = new DishCRUDModel;
    }

    public function index()
    {
        $data['data'] = $this->dishCRUD->get_itemCRUD();

        $this->load->view('dish/header');
        $this->load->view('theme/menu');
        $this->load->view('dish/list', $data);
        $this->load->view('theme/footer');
        $this->load->view('dish/footer');
    }

    public function json()
    {
        $item = $this->dishCRUD->get_itemCRUD();
        header('Content-Type: application/json');
        echo json_encode($item, JSON_PRETTY_PRINT);
    }

    public function show($id)
    {
        $item = $this->dishCRUD->find_item($id);

        $this->load->view('theme/header');
        $this->load->view('dish/show', array('item' => $item));
        $this->load->view('theme/footer');
    }

    public function create()
    {
        $this->load->view('theme/header');
        $this->load->view('dish/create');
        $this->load->view('theme/footer');
    }

    public function store()
    {
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('errors', validation_errors());
            redirect(base_url('dish/create'));
        } else {
            $this->dishCRUD->insert_item();
            redirect(base_url('dish'));
        }
    }

    public function edit($id)
    {
        $item = $this->dishCRUD->find_item($id);

        $this->load->view('theme/header');
        $this->load->view('dish/edit', array('item' => $item));
        $this->load->view('theme/footer');
    }

    public function update($id)
    {
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('errors', validation_errors());
            redirect(base_url('dish/edit/' . $id));
        } else {
            $this->dishCRUD->update_item($id);
            redirect(base_url('dish'));
        }
    }

    public function delete($id)
    {
        $item = $this->dishCRUD->delete_item($id);
        redirect(base_url('dish'));
    }
}