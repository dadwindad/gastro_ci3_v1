<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
	public function index()
	{
		$this->load->view('pages/header');
		$this->load->view('theme/menu');
		$this->load->view('pages/home');

		$this->load->view('theme/footer');
		$this->load->view('pages/footer');
	}

	public function about()
	{
		$this->load->view('pages/header');
		$this->load->view('theme/menu');
		$this->load->view('pages/about');
		$this->load->view('theme/footer');
		$this->load->view('pages/footer');
	}

	public function rule()
	{
		$this->load->view('pages/header');
		$this->load->view('theme/menu');
		$this->load->view('pages/rule');
		$this->load->view('theme/footer');
		$this->load->view('pages/footer');
	}

	public function permission()
	{
		$this->load->view('pages/header');
		$this->load->view('theme/menu');
		$this->load->view('pages/permission');
		$this->load->view('theme/footer');
		$this->load->view('pages/footer');
	}

}