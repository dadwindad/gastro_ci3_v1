<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Attraction extends CI_Controller
{
   public $attractionCRUD;

   public function __construct()
   {
      parent::__construct();

      // $this->load->library('form_validation');
      // $this->load->library('session');
      $this->load->model('AttractionCRUDModel');

      $this->attractionCRUD = new AttractionCRUDModel;
   }

   public function index()
   {
      $data['data'] = $this->attractionCRUD->get_itemCRUD();

      $this->load->view('attraction/header');
      $this->load->view('theme/menu');
      $this->load->view('attraction/list', $data);

      $this->load->view('theme/footer');
      $this->load->view('attraction/footer');
   }

   public function json()
   {
      $item = $this->attractionCRUD->get_itemCRUD();
      header('Content-Type: application/json');
      echo json_encode($item, JSON_PRETTY_PRINT);
   }

   public function show($id)
   {
      $item = $this->attractionCRUD->find_item($id);

      $this->load->view('theme/header');
      $this->load->view('attraction/show', array('item' => $item));
      $this->load->view('theme/footer');
   }

   public function create()
   {
      $this->load->view('theme/header');
      $this->load->view('attraction/create');
      $this->load->view('theme/footer');
   }

   public function store()
   {
      $this->form_validation->set_rules('title', 'Title', 'required');
      $this->form_validation->set_rules('description', 'Description', 'required');

      if ($this->form_validation->run() == FALSE) {
         $this->session->set_flashdata('errors', validation_errors());
         redirect(base_url('attraction/create'));
      } else {
         $this->attractionCRUD->insert_item();
         redirect(base_url('attraction'));
      }
   }

   public function edit($id)
   {
      $item = $this->attractionCRUD->find_item($id);

      $this->load->view('theme/header');
      $this->load->view('attraction/edit', array('item' => $item));
      $this->load->view('theme/footer');
   }

   public function update($id)
   {
      $this->form_validation->set_rules('title', 'Title', 'required');
      $this->form_validation->set_rules('description', 'Description', 'required');

      if ($this->form_validation->run() == FALSE) {
         $this->session->set_flashdata('errors', validation_errors());
         redirect(base_url('attraction/edit/' . $id));
      } else {
         $this->attractionCRUD->update_item($id);
         redirect(base_url('attraction'));
      }
   }

   public function delete($id)
   {
      $item = $this->attractionCRUD->delete_item($id);
      redirect(base_url('attraction'));
   }

}