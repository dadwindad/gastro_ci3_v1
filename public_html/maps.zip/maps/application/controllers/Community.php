<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Community extends CI_Controller
{
	public $communityCRUD;

	public function __construct()
	{
		parent::__construct();

		$this->load->model('CommunityCRUDModel');

		$this->communityCRUD = new CommunityCRUDModel;
	}

	public function index()
	{
		$data['data'] = $this->communityCRUD->get_itemCRUD();

		$this->load->view('community/header');
		$this->load->view('theme/menu');
		$this->load->view('community/list', $data);

		$this->load->view('theme/footer');
		$this->load->view('community/footer');

	}

	public function json()
	{
		$item = $this->communityCRUD->get_itemCRUD();
		header('Content-Type: application/json');
		echo json_encode($item, JSON_PRETTY_PRINT);
	}


	public function show($id)
	{
		$item = $this->communityCRUD->find_item($id);

		$this->load->view('theme/header');
		$this->load->view('community/show', array('item' => $item));
		$this->load->view('theme/footer');
	}

	public function create()
	{
		$this->load->view('theme/header');
		$this->load->view('community/create');
		$this->load->view('theme/footer');
	}

	public function store()
	{
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('description', 'Description', 'required');

		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errors', validation_errors());
			redirect(base_url('community/create'));
		} else {
			$this->communityCRUD->insert_item();
			redirect(base_url('community'));
		}
	}

	public function edit($id)
	{
		$item = $this->communityCRUD->find_item($id);

		$this->load->view('theme/header');
		$this->load->view('community/edit', array('item' => $item));
		$this->load->view('theme/footer');
	}

	public function update($id)
	{
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('description', 'Description', 'required');

		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('errors', validation_errors());
			redirect(base_url('community/edit/' . $id));
		} else {
			$this->communityCRUD->update_item($id);
			redirect(base_url('community'));
		}
	}

	public function delete($id)
	{
		$item = $this->communityCRUD->delete_item($id);
		redirect(base_url('community'));
	}
}