<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Ingredient extends CI_Controller
{
    public $ingredientCRUD;

    public function __construct()
    {
        parent::__construct();

        $this->load->model('IngredientCRUDModel');

        $this->ingredientCRUD = new IngredientCRUDModel;
    }

    public function index()
    {
        $data['data'] = $this->ingredientCRUD->get_itemCRUD();

        $this->load->view('ingredient/header');
        $this->load->view('theme/menu');
        $this->load->view('ingredient/list', $data);
        $this->load->view('theme/footer');
        $this->load->view('ingredient/footer');
    }

    public function json()
    {
        $item = $this->ingredientCRUD->get_itemCRUD();
        header('Content-Type: application/json');
        echo json_encode($item, JSON_PRETTY_PRINT);
    }

    public function show($id)
    {
        $item = $this->ingredientCRUD->find_item($id);

        $this->load->view('theme/header');
        $this->load->view('ingredient/show', array('item' => $item));
        $this->load->view('theme/footer');
    }

    public function create()
    {
        $this->load->view('theme/header');
        $this->load->view('ingredient/create');
        $this->load->view('theme/footer');
    }

    public function store()
    {
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('errors', validation_errors());
            redirect(base_url('ingredient/create'));
        } else {
            $this->ingredientCRUD->insert_item();
            redirect(base_url('ingredient'));
        }
    }

    public function edit($id)
    {
        $item = $this->ingredientCRUD->find_item($id);

        $this->load->view('theme/header');
        $this->load->view('ingredient/edit', array('item' => $item));
        $this->load->view('theme/footer');
    }

    public function update($id)
    {
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('errors', validation_errors());
            redirect(base_url('ingredient/edit/' . $id));
        } else {
            $this->ingredientCRUD->update_item($id);
            redirect(base_url('ingredient'));
        }
    }

    public function delete($id)
    {
        $item = $this->ingredientCRUD->delete_item($id);
        redirect(base_url('ingredient'));
    }
}