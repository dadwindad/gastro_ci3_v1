<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Map extends CI_Controller
{
	public function index()
	{
		$this->load->view('map/header');
		$this->load->view('theme/menu');
		$this->load->view('map/map');
		$this->load->view('theme/footer');
		$this->load->view('map/footer');
	}
}