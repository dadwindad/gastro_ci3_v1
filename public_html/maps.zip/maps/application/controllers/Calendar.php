<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Calendar extends CI_Controller
{
    public function index()
    {
        $this->load->view('calendar/header');
        $this->load->view('theme/menu');
        $this->load->view('calendar/calendar');

        $this->load->view('theme/footer');
        $this->load->view('calendar/footer');
    }

}