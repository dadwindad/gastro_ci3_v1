<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

////////////////////////////////////////////
$route['calendar'] = "calendar/index";
$route['about'] = "home/about";
$route['rule'] = "home/rule";
$route['permission'] = "home/permission";

$route['attraction'] = "attraction/index";
$route['attraction/(:num)'] = "attraction/show/$1";
$route['attractionCreate']['post'] = "attraction/store";
$route['attractionEdit/(:any)'] = "attraction/edit/$1";
$route['attractionUpdate/(:any)']['put'] = "attraction/update/$1";
$route['attractionDelete/(:any)']['delete'] = "attraction/delete/$1";

$route['community'] = "community/index";
$route['community/(:num)'] = "community/show/$1";
$route['communityCreate']['post'] = "community/store";
$route['communityEdit/(:any)'] = "community/edit/$1";
$route['communityUpdate/(:any)']['put'] = "community/update/$1";
$route['communityDelete/(:any)']['delete'] = "community/delete/$1";

$route['dish'] = "dish/index";
$route['dish/(:num)'] = "dish/show/$1";
$route['dishCreate']['post'] = "dish/store";
$route['dishEdit/(:any)'] = "dish/edit/$1";
$route['dishUpdate/(:any)']['put'] = "dish/update/$1";
$route['dishDelete/(:any)']['delete'] = "dish/delete/$1";

$route['ingredient'] = "ingredient/index";
$route['ingredient/(:num)'] = "ingredient/show/$1";
$route['ingredientCreate']['post'] = "ingredient/store";
$route['ingredientEdit/(:any)'] = "ingredient/edit/$1";
$route['ingredientUpdate/(:any)']['put'] = "ingredient/update/$1";
$route['ingredientDelete/(:any)']['delete'] = "ingredient/delete/$1";

$route['member'] = "member/index";
$route['member/(:num)'] = "member/show/$1";
$route['memberCreate']['post'] = "member/store";
$route['memberEdit/(:any)'] = "member/edit/$1";
$route['memberUpdate/(:any)']['put'] = "member/update/$1";
$route['memberDelete/(:any)']['delete'] = "member/delete/$1";

$route['restaurant'] = "restaurant/index";
$route['restaurant/(:num)'] = "restaurant/show/$1";
$route['restaurantCreate']['post'] = "restaurant/store";
$route['restaurantEdit/(:any)'] = "restaurant/edit/$1";
$route['restaurantUpdate/(:any)']['put'] = "restaurant/update/$1";
$route['restaurantDelete/(:any)']['delete'] = "restaurant/delete/$1";