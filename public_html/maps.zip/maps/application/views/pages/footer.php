<!-- BEGIN: Vendor JS-->
<script src="/maps/app-assets/vendors/js/vendors.min.js"></script>
<!-- BEGIN Vendor JS-->


<!-- BEGIN: Theme JS-->
<script src="/maps/app-assets/js/core/app-menu.js" defer></script>
<script src="/maps/app-assets/js/core/app.js" defer></script>
<!-- END: Theme JS-->

<script>
$(window).on("load", function() {
    if (feather) {
        feather.replace({
            width: 14,
            height: 14,
        });
    }
});
</script>
</body>
<!-- END: Body-->

</html>