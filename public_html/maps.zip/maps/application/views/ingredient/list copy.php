<!-- BEGIN: Content-->
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row"></div>
        <div class="content-body">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">วัตถุดิบ</h4>

                    <div>
                        <?= anchor(base_url('ingredient/create'), '+ เพิ่มวัตถุดิบ') ?>
                    </div>
                </div>
                <div class="card-body">

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th></th>
                                <th>Detail</th>
                                <!-- <th>Action</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($data as $item) { ?>
                                <tr>
                                    <td>
                                        <?= $item->ingred_name_thai; ?>
                                    </td>
                                    <td>
                                        <?= $item->ingred_name_eng; ?>
                                    </td>
                                    <td>
                                        <?= $item->ingred_details; ?>
                                    </td>
                                    <!-- <td>
                                    <form method="DELETE"
                                        action="<?= base_url('itemCRUD/delete/' . $item->ingred_id); ?>">
                                        <a class="btn btn-info" href="<?= base_url('itemCRUD/' . $item->ingred_id) ?>">
                                            show</a>
                                        <a class="btn btn-primary"
                                            href="<?= base_url('itemCRUD/edit/' . $item->ingred_id) ?>"> Edit</a>
                                        <button type="submit" class="btn btn-danger"> Delete</button>
                                    </form>
                                </td> -->
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="sidenav-overlay"></div>
<div class="drag-target"></div>