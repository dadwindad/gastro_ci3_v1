<!-- BEGIN: Footer-->
<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0">
        <span class="float-md-start d-block d-md-inline-block mt-25">สงวนลิขสิทธิ์ &copy; 2022<a class="ms-25" href="#"
                target="_blank">โครงการวิจัยการบรูณาการระบบสารสนเทศทางภูมิศาสตร์เพื่อยกระดับการท่องเที่ยวเชิงวัฒนธรรมอาหารของประเทศไทย</a><span
                class="d-none d-sm-inline-block">, All rights Reserved</span></span><span
            class="float-md-end d-none d-md-block">มหาวิทยาลัยราชภัฏเลย</span>
    </p>
</footer>

<button class="btn btn-primary btn-icon scroll-top" type="button">
    <i data-feather="arrow-up"></i>
</button>
<!-- END: Footer-->