<!-- BEGIN: Content-->
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row"></div>
        <div class="content-body">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">ชุมชน</h4>

                    <div>
                        <?= anchor(base_url('community/create'), '+ เพิ่มชุมชน') ?>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Column Search -->

                    <div class="card-datatable">
                        <table class="dt-community table table-responsive">
                            <thead>
                                <tr>
                                    <th>ชุมชน</th>
                                    <th>รายละเอียด</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ชุมชน</th>
                                    <th>รายละเอียด</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    </section>
                    <!--/ Column Search -->
                </div>
            </div>
        </div>
    </div>
</div>

<div class="sidenav-overlay"></div>
<div class="drag-target"></div>