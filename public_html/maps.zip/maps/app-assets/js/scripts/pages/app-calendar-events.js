/**
 * App Calendar Events
 */

"use strict";

var date = new Date();
var nextDay = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
// prettier-ignore
var nextMonth = date.getMonth() === 11 ? new Date(date.getFullYear() + 1, 0, 1) : new Date(date.getFullYear(), date.getMonth() + 1, 1);
// prettier-ignore
var prevMonth = date.getMonth() === 11 ? new Date(date.getFullYear() - 1, 0, 1) : new Date(date.getFullYear(), date.getMonth() - 1, 1);

var events = [
	{
		id: 2,
		url: "",
		title: "ส่งท้ายปีเก่า",
		start: new Date(date.getFullYear(), 12, -0),
		end: new Date(date.getFullYear(), 12, -0),
		allDay: true,
		extendedProps: {
			calendar: "inter",
		},
	},
	{
		id: 3,
		url: "",
		title: "ต้อนรับปีใหม่",
		start: new Date(date.getFullYear() + 1, 1, -30),
		end: new Date(date.getFullYear() + 1, 1, -30),
		allDay: true,
		extendedProps: {
			calendar: "inter",
		},
	},
	{
		id: 4,
		url: "",
		title: "เทศกาล Hua Hin International Jazz Festival 2022",
		start: new Date(2022, 12, -29),
		end: new Date(2022, 12, -29),
		allDay: true,
		extendedProps: {
			calendar: "eastern",
		},
	},
	{
		id: 5,
		url: "",
		title: "สีสันแห่งดอยตุง",
		start: new Date(2022, 12, -29),
		end: new Date(2022, 12, -29),
		allDay: true,
		extendedProps: {
			calendar: "northern",
		},
	},
	{
		id: 6,
		url: "",
		title: "งานรักอ่าวลึก",
		start: new Date(2022, 12, -26),
		end: new Date(2022, 12, -26),
		allDay: true,
		extendedProps: {
			calendar: "southern",
		},
	},
	{
		id: 7,
		url: "",
		title: "ประเพณีไหลแพไฟเฉลิมพระเกียรติและพิธีขอบคุณพืชพันธุ์ธัญญาหาร",
		start: new Date(2022, 12, -26),
		end: new Date(2022, 12, -26),
		allDay: true,
		extendedProps: {
			calendar: "northern",
		},
	},
	{
		id: 8,
		url: "",
		title: "งานบรรเลงดนตรี - แสดงนาฏศิลป์ไทย และศิลปวัฒนธรรมไทย",
		start: new Date(2022, 12, -26),
		end: new Date(2022, 12, -26),
		allDay: true,
		extendedProps: {
			calendar: "central",
		},
	},
	{
		id: 9,
		url: "",
		title: "Field For Fun ไร่วนาทิพย์ HutZa Cafe หัวหิน",
		start: new Date(2022, 12, -26),
		end: new Date(2022, 12, -26),
		allDay: true,
		extendedProps: {
			calendar: "eastern",
		},
	},
	{
		id: 10,
		url: "",
		title: "วันพ่อแห่งชาติ",
		start: new Date(date.getFullYear(), 12, -26),
		end: new Date(date.getFullYear(), 12, -26),
		allDay: true,
		extendedProps: {
			calendar: "thai",
			description: "Lecture",
		},
	},
	{
		id: 11,
		url: "",
		title: "งานฉลองสมโภชศาลหลักเมือง และจังหวัดนนทบุรีครบ 473 ปี",
		allDay: true,
		start: new Date(2022, 12, -30),
		end: new Date(2022, 12, -30),
		extendedProps: {
			calendar: "central",
		},
	},
	{
		id: 12,
		url: "",
		title: "งานประจำปีทุ่งศรีเมืองจังหวัดอุดรธานี ประจำปี 2565",
		allDay: true,
		start: new Date(2022, 12, -30),
		end: new Date(2022, 12, -30),
		extendedProps: {
			calendar: "issan",
		},
	},
	{
		id: 13,
		url: "",
		title: "กาดฮิมน้ำกก",
		allDay: true,
		start: new Date(2022, 12, -29),
		end: new Date(2022, 12, -29),
		extendedProps: {
			calendar: "northern",
		},
	},
	{
		id: 14,
		url: "",
		title: "หัวหิน รักษ์เล RUN-FUN-WALK",
		start: new Date(2022, 12, -25),
		end: new Date(2022, 12, -25),
		allDay: true,
		extendedProps: {
			calendar: "eastern",
		},
	},
	{
		id: 15,
		url: "",
		title: "งานนมัสการพระแท่นดงรัง ณ วัดพระแท่นดงรังวรวิหาร อำเภอท่ามะกา",
		start: new Date(2023, 3, -30),
		end: new Date(2023, 3, -30),
		allDay: true,
		extendedProps: {
			calendar: "central",
		},
	},
	{
		id: 16,
		url: "",
		title: "กิจกรรมส่งเสริมตลาดวัฒนธรรมจังหวัดสตูล Satun Street Show 2023",
		start: new Date(2023, 3, -13),
		end: new Date(2023, 3, -13),
		allDay: true,
		extendedProps: {
			calendar: "southern",
		},
	},
	{
		id: 17,
		url: "",
		title: "งานโคบาลเลาขวัญ จังหวัดกาญจนบุรี",
		start: new Date(2023, 3, -12),
		end: new Date(2023, 3, -12),
		allDay: true,
		extendedProps: {
			calendar: "central",
		},
	},
	{
		id: 18,
		url: "",
		title: "แห่ผ้าห่มพระธาตุศรีสุราษฎร",
		start: new Date(2023, 3, -11),
		end: new Date(2023, 3, -11),
		allDay: true,
		extendedProps: {
			calendar: "southern",
		},
	},
	{
		id: 19,
		url: "",
		title: "กิจกรรมแข่งขันสุขภาพ ๒๕๖๖ เซนทัลหาดใหญ่",
		start: new Date(2023, 3, -1),
		end: new Date(2023, 3, -1),
		allDay: true,
		extendedProps: {
			calendar: "southern",
		},
	},
	{
		id: 20,
		url: "",
		title: "การปิดทอง ประจำปี หลวงพ่อโตวัดป่าเลไลยก์ ประจำปี 2566",
		start: new Date(2023, 3, -5),
		end: new Date(2023, 3, -5),
		allDay: true,
		extendedProps: {
			calendar: "central",
		},
	},
	{
		id: 21,
		url: "",
		title: "งานกาชาดมะม่วงแฟร์ ของดีหนองวัวซอ",
		start: new Date(2023, 3, -2),
		end: new Date(2023, 3, -2),
		allDay: true,
		extendedProps: {
			calendar: "issan",
		},
	},
	{
		id: 22,
		url: "",
		title:
			"นิทรรศการ “วันคล้ายวันพระราชสมภพ สมเด็จพระกนิษฐาธิราชเจ้า กรมสมเด็จพระเทพรัตนราชสุดา ฯ สยามบรมราชกุมารี” พิพิธภัณฑ์เมืองนราธิวาส",
		start: new Date(2023, 3, -2),
		end: new Date(2023, 3, -2),
		allDay: true,
		extendedProps: {
			calendar: "southern",
		},
	},
	{
		id: 23,
		url: "",
		title:
			"สีสันตะวันออก สีสัน EEC Colorful ตำบลบางปลาสร้อย อำเภอเมืองชลบุรี จังหวัดชลบุรี",
		start: new Date(2023, 3, -1),
		end: new Date(2023, 3, -1),
		allDay: true,
		extendedProps: {
			calendar: "eastern",
		},
	},
	{
		id: 24,
		url: "",
		title:
			"เทศกาลโขนกรุงศรีปีที่ 4 (รามายณะนานาชาติ) นักงานการท่องเที่ยวและกีฬาจังหวัดพระนครศรีอยุธยา",
		start: new Date(2023, 3, -1),
		end: new Date(2023, 3, -1),
		allDay: true,
		extendedProps: {
			calendar: "central",
		},
	},
	{
		id: 25,
		url: "",
		title:
			"งานวัฒนธรรมสองฝั่งเจ้าพระยา มหาเจษฎาบดินทร์ ประจำปีงบประมาณ พ.ศ. 2566 ศาลากลางจังหวัดนนทบุรี",
		start: new Date(2023, 3, -1),
		end: new Date(2023, 3, -1),
		allDay: true,
		extendedProps: {
			calendar: "eastern",
		},
	},
	{
		id: 26,
		url: "",
		title:
			"กิจกรรมการเกี่ยวข้าว สืบสานประเพณีวัฒนธรรม พลิกนาร้าง เป็นนารักษ์ ปีที่ ๕ อำเภอนาทวี จังหวัดสงขลา",
		start: new Date(2023, 3, -6),
		end: new Date(2023, 3, -6),
		allDay: true,
		extendedProps: {
			calendar: "southern",
		},
	},
	{
		id: 27,
		url: "",
		title: "งานปอยขันโตก รวมใจไท-ยวน ศาลากลางจังหวัดราชบุรี",
		start: new Date(2023, 3, -6),
		end: new Date(2023, 3, -6),
		allDay: true,
		extendedProps: {
			calendar: "central",
		},
	},
	{
		id: 28,
		url: "",
		title:
			"งานแถลงข่าว การจัดงาน มหกรรมศิลปะนานาชาติ Thailand Biennale, Chiang Rai 2023",
		start: new Date(2023, 3, -6),
		end: new Date(2023, 3, -6),
		allDay: true,
		extendedProps: {
			calendar: "northern",
		},
	},
	{
		id: 29,
		url: "",
		title: "​มหกรรมวัฒนธรรม “เต๊อะเติ๋น เดิ่นโคราช” ",
		start: new Date(2023, 3, -7),
		end: new Date(2023, 3, -7),
		allDay: true,
		extendedProps: {
			calendar: "issan",
		},
	},
	{
		id: 30,
		url: "",
		title: "โครงการสายวัฒนธรรม รากราชสีมา “รถไฟจะไปโคราช” ",
		start: new Date(2023, 3, -14),
		end: new Date(2023, 3, -14),
		allDay: true,
		extendedProps: {
			calendar: "issan",
		},
	},
	{
		id: 31,
		url: "",
		title: "เทศกาลตามรอยอารยธรรมขอมโบราณปราสาทศิลา",
		start: new Date(2023, 3, -23),
		end: new Date(2023, 3, -23),
		allDay: true,
		extendedProps: {
			calendar: "eastern",
		},
	},
	{
		id: 32,
		url: "",
		title:
			"งานตลาดนัดภูมิปัญญาสภาวัฒนธรรมอำเภอเมืองเพชรบุรี “ยลศิลป์ ถิ่นอาหาร ย่านต้นม่วง” ",
		start: new Date(2023, 3, -21),
		end: new Date(2023, 3, -21),
		allDay: true,
		extendedProps: {
			calendar: "central",
		},
	},
];
