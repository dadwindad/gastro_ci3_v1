async function fetchDataIngred(table) {
	let point = [];

	const response = await fetch(`/maps/${table}/json`);
	const jSondata = await response.json();

	jSondata.forEach(function (params) {
		var data = [params.ingred_name_thai, params.ingred_detail];
		point = [...point, data];
		// console.log(point);
	});

	return point;
}

async function genDataTable() {
	try {
		const ingredientDT = await fetchDataIngred("ingredient");
		// console.log(ingredientDT);

		////////datatable/////////////

		var dt_filter_table_ingredient = $(".dt-ingredient");
		if (dt_filter_table_ingredient.length) {
			// Setup - add a text input to each footer cell
			$(".dt-ingredient thead tr").clone(true).appendTo(".dt-ingredient thead");
			$(".dt-ingredient thead tr:eq(1) th").each(function (i) {
				var title = $(this).text();
				$(this).html(
					'<input type="text" class="form-control form-control-sm" placeholder="Search ' +
						title +
						'" />'
				);

				$("input", this).on("keyup change", function () {
					if (dt_filter_ingredient.column(i).search() !== this.value) {
						dt_filter_ingredient.column(i).search(this.value).draw();
					}
				});
			});

			var dt_filter_ingredient = dt_filter_table_ingredient.DataTable({
				// ajax: "/maps/ingredient/json",
				data: ingredientDT,
				// columns: [{ title: "Name" }, { title: "Email" }],
				dom: '<"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
				orderCellsTop: true,
				language: {
					paginate: {
						// remove previous & next text from pagination
						previous: "&nbsp;",
						next: "&nbsp;",
					},
				},
			});
		}
	} catch (error) {
		console.error(error);
	}
}

///////////////////////////////////////////
genDataTable();
