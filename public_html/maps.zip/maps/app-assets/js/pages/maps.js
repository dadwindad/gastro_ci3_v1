// Layer Control
// --------------------------------------------------------------------
// var base_url = window.location.origin;

if ($("#layer-control-map").length) {
	$.getScript(
		"/maps/app-assets/js/scripts/maps/leaflet-color-markers.js",
		function () {
			async function fetchDataAttr(table) {
				let point = [];

				const response = await fetch(`/maps/${table}/json`);
				const jSondata = await response.json();

				jSondata.forEach(function (params) {
					var data = L.marker([params.attr_lat, params.attr_long], {
						icon: blueIcon,
					})
						.bindPopup(params.attr_name)
						.on("click", function (e) {
							let key = params.attr_id;
							let value = params.attr_long + "," + params.attr_long;

							localStorage.setItem(key, value);
							console.log(localStorage.getItem(key));
						});
					point = [...point, data];
					// console.log(point);
				});

				return point;
			}

			async function fetchDataComm(table) {
				let point = [];

				const response = await fetch(`/maps/${table}/json`);
				const jSondata = await response.json();

				jSondata.forEach(function (params) {
					var data = L.marker([params.comm_lat, params.comm_long], {
						icon: greenIcon,
					})
						.bindPopup(params.comm_name)
						.on("click", function (e) {
							let key = params.comm_id;
							let value = params.comm_long + "," + params.comm_long;

							localStorage.setItem(key, value);
							console.log(localStorage.getItem(key));
						});
					point = [...point, data];
					// console.log(point);
				});

				return point;
			}

			async function map() {
				try {
					//////////////////point/////////////////////
					const attractionPoint = await fetchDataAttr("attraction");
					const attractionGroup = L.layerGroup(attractionPoint);

					const communityPoint = await fetchDataComm("community");
					const communityGroup = L.layerGroup(communityPoint);

					// console.log(attractionPoint);

					/////////////////map//////////////////////

					var street_d = L.tileLayer(
						"https://{s}.tile.osm.org/{z}/{x}/{y}.png",
						{
							attribution:
								'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>',
						}
					);

					var street_nd = L.tileLayer(
						"https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png",
						{
							attribution:
								'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, &copy; <a href="https://carto.com/attribution">CARTO</a>',
						}
					);

					const mbAttr =
						'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>';
					const mbUrl =
						"https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw";
					const satellite = L.tileLayer(mbUrl, {
						id: "mapbox/satellite-v9",
						tileSize: 512,
						zoomOffset: -1,
						attribution: mbAttr,
					});

					var baseMaps = {
						ถนนมีรายละเอียด: street_d,
						ถนนไม่มีรายละเอียด: street_nd,
					};

					var overlayMaps = {
						สถานที่ท่องเที่ยว: attractionGroup,
						ชุมชน: communityGroup,
					};

					var layerControl = L.map("layer-control-map", {
						minZoom: 0,
						maxZoom: 18,
						layers: [street_nd, attractionGroup, communityGroup],
					});

					layerControl.setView([13.5, 101.5], 6);

					L.control.layers(baseMaps, overlayMaps).addTo(layerControl);

					L.tileLayer("https://c.tile.osm.org/{z}/{x}/{y}.png", {
						attribution:
							'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>',
						maxZoom: 18,
					}).addTo(layerControl);
				} catch (error) {
					console.error(error);
				}
			}

			///////////////////////////////////////////
			map();

			var orig_loc = L.latLng(13.742632, 100.527778);
			var dest_loc = L.latLng(13.737307, 100.533287);

			// begin_routing(orig_loc, dest_loc, layerControl);
		}
	);
}

/* Start routing control  */
function begin_routing(orig_loc, dest_loc, map) {
	L.Routing.control({
		waypoints: [
			orig_loc,
			dest_loc,
			//L.latLng(14.1688, 100.2918),
			//L.latLng(13.7042, 100.6032)
		],
		routeWhileDragging: true,
		routeDragInterval: 500,
		collapsible: true, // hide/show panel routing
		reverseWaypoints: false,
		showAlternatives: false,
		createMarker: function (i, wp, nWps) {
			switch (i) {
				case 0:
					return L.marker(wp.latLng, {
						icon: redIcon,
						draggable: true,
					}).bindPopup("<b>" + "Origin" + "</b>");
				case nWps - 1:
					return L.marker(wp.latLng, {
						icon: redIcon,
						draggable: true,
					}).bindPopup("<b>" + "Destination" + "</b>");
				default:
					return L.marker(wp.latLng, {
						icon: greyIcon,
						draggable: true,
					}).bindPopup("<b>" + "Waypoint" + "</b>");
			}
		},
	}).addTo(map);
}
