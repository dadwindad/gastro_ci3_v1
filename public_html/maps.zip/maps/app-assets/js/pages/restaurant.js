async function fetchDataRest(table) {
	let point = [];

	const response = await fetch(`/maps/${table}/json`);
	const jSondata = await response.json();

	jSondata.forEach(function (params) {
		var data = [params.rest_name_thai, params.rest_highlight];
		point = [...point, data];
		// console.log(point);
	});

	return point;
}

async function genDataTable() {
	try {
		const restaurantDT = await fetchDataRest("restaurant");
		// console.log(restaurantDT);

		////////datatable/////////////

		var dt_filter_table_restaurant = $(".dt-restaurant");
		if (dt_filter_table_restaurant.length) {
			// Setup - add a text input to each footer cell
			$(".dt-restaurant thead tr").clone(true).appendTo(".dt-restaurant thead");
			$(".dt-restaurant thead tr:eq(1) th").each(function (i) {
				var title = $(this).text();
				$(this).html(
					'<input type="text" class="form-control form-control-sm" placeholder="Search ' +
						title +
						'" />'
				);

				$("input", this).on("keyup change", function () {
					if (dt_filter_restaurant.column(i).search() !== this.value) {
						dt_filter_restaurant.column(i).search(this.value).draw();
					}
				});
			});

			var dt_filter_restaurant = dt_filter_table_restaurant.DataTable({
				// ajax: "/maps/restaurant/json",
				data: restaurantDT,
				// columns: [{ title: "Name" }, { title: "Email" }],
				dom: '<"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
				orderCellsTop: true,
				language: {
					paginate: {
						// remove previous & next text from pagination
						previous: "&nbsp;",
						next: "&nbsp;",
					},
				},
			});
		}
	} catch (error) {
		console.error(error);
	}
}

///////////////////////////////////////////
genDataTable();
