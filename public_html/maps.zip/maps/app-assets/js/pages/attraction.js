async function fetchDataAttr(table) {
	let point = [];

	const response = await fetch(`/maps/${table}/json`);
	const jSondata = await response.json();

	jSondata.forEach(function (params) {
		var data = [
			params.attr_name,
			params.attr_history,
			params.attr_lat,
			params.attr_long,
		];
		point = [...point, data];
		// console.log(point);
	});

	return point;
}

async function genDataTable() {
	try {
		const attractionDT = await fetchDataAttr("attraction");
		// console.log(attractionDT);

		////////datatable/////////////

		var dt_filter_table_attraction = $(".dt-attraction");
		if (dt_filter_table_attraction.length) {
			// Setup - add a text input to each footer cell
			$(".dt-attraction thead tr").clone(true).appendTo(".dt-attraction thead");
			$(".dt-attraction thead tr:eq(1) th")
				.slice(0, -1) //except last column
				.each(function (i) {
					var title = $(this).text();
					$(this).html(
						'<input type="text" class="form-control form-control-sm" placeholder="Search ' +
							title +
							'" />'
					);

					$("input", this).on("keyup change", function () {
						if (dt_filter_attraction.column(i).search() !== this.value) {
							dt_filter_attraction.column(i).search(this.value).draw();
						}
					});
				});

			var dt_filter_attraction = dt_filter_table_attraction.DataTable({
				// ajax: "/maps/attraction/json",
				data: attractionDT,
				columnDefs: [
					{
						targets: -1,
						data: null,
						defaultContent: `<img class="map-icon" role="button" src="/maps/app-assets/images/icons/map-icon.png" width="40">`,
						orderable: false,
					},
				],
				dom: '<"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
				orderCellsTop: true,
				language: {
					paginate: {
						// remove previous & next text from pagination
						previous: "&nbsp;",
						next: "&nbsp;",
					},
				},
			});

			$(".dt-attraction tbody").on("click", "img", function () {
				var data = dt_filter_attraction.row($(this).parents("tr")).data();

				var url = `https://www.google.com/maps/@${data[2]},${data[3]},16z`;
				window.open(url, "_blank");

				// $(
				// 	`a[href^="https://www.google.com/maps/@${data[2]},${data[3]},16z"]`
				// ).attr("target", "_blank");
			});
		}
	} catch (error) {
		console.error(error);
	}
}

///////////////////////////////////////////
genDataTable();
