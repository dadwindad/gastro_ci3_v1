async function fetchDataComm(table) {
	let point = [];

	const response = await fetch(`/maps/${table}/json`);
	const jSondata = await response.json();

	jSondata.forEach(function (params) {
		var data = [params.comm_name, params.comm_detail];
		point = [...point, data];
		// console.log(point);
	});

	return point;
}

async function genDataTable() {
	try {
		const communityDT = await fetchDataComm("community");
		// console.log(communityDT);

		////////datatable/////////////

		var dt_filter_table_community = $(".dt-community");
		if (dt_filter_table_community.length) {
			// Setup - add a text input to each footer cell
			$(".dt-community thead tr").clone(true).appendTo(".dt-community thead");
			$(".dt-community thead tr:eq(1) th").each(function (i) {
				var title = $(this).text();
				$(this).html(
					'<input type="text" class="form-control form-control-sm" placeholder="Search ' +
						title +
						'" />'
				);

				$("input", this).on("keyup change", function () {
					if (dt_filter_community.column(i).search() !== this.value) {
						dt_filter_community.column(i).search(this.value).draw();
					}
				});
			});

			var dt_filter_community = dt_filter_table_community.DataTable({
				// ajax: "/maps/community/json",
				data: communityDT,
				// columns: [{ title: "Name" }, { title: "Email" }],
				dom: '<"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
				orderCellsTop: true,
				language: {
					paginate: {
						// remove previous & next text from pagination
						previous: "&nbsp;",
						next: "&nbsp;",
					},
				},
			});
		}
	} catch (error) {
		console.error(error);
	}
}

///////////////////////////////////////////
genDataTable();
