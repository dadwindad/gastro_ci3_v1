async function fetchDataDish(table) {
	let point = [];

	const response = await fetch(`/maps/${table}/json`);
	const jSondata = await response.json();

	jSondata.forEach(function (params) {
		var data = [params.dish_name_thai, params.dish_detail];
		point = [...point, data];
		// console.log(point);
	});

	return point;
}

async function genDataTable() {
	try {
		const dishDT = await fetchDataDish("dish");
		// console.log(dishDT);

		////////datatable/////////////

		var dt_filter_table_dish = $(".dt-dish");
		if (dt_filter_table_dish.length) {
			// Setup - add a text input to each footer cell
			$(".dt-dish thead tr").clone(true).appendTo(".dt-dish thead");
			$(".dt-dish thead tr:eq(1) th").each(function (i) {
				var title = $(this).text();
				$(this).html(
					'<input type="text" class="form-control form-control-sm" placeholder="Search ' +
						title +
						'" />'
				);

				$("input", this).on("keyup change", function () {
					if (dt_filter_dish.column(i).search() !== this.value) {
						dt_filter_dish.column(i).search(this.value).draw();
					}
				});
			});

			var dt_filter_dish = dt_filter_table_dish.DataTable({
				// ajax: "/maps/dish/json",
				data: dishDT,
				// columns: [{ title: "Name" }, { title: "Email" }],
				dom: '<"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
				orderCellsTop: true,
				language: {
					paginate: {
						// remove previous & next text from pagination
						previous: "&nbsp;",
						next: "&nbsp;",
					},
				},
			});
		}
	} catch (error) {
		console.error(error);
	}
}

///////////////////////////////////////////
genDataTable();
